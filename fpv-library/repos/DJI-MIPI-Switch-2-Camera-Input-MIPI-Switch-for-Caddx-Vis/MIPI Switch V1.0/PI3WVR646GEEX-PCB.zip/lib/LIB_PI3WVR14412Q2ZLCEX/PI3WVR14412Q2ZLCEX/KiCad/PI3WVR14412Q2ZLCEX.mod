PCBNEW-LibModule-V1  2024-08-12 20:58:08
# encoding utf-8
Units mm
$INDEX
QFN40P300X600X80-41N
$EndINDEX
$MODULE QFN40P300X600X80-41N
Po 0 0 0 15 66ba6950 00000000 ~~
Li QFN40P300X600X80-41N
Cd 40-TQFN (ZLC)
Kw Integrated Circuit
Sc 0
At SMD
AR 
Op 0 0 0
T0 0 0 1.27 1.27 0 0.254 N V 21 N "IC**"
T1 0 0 1.27 1.27 0 0.254 N I 21 N "QFN40P300X600X80-41N"
DS -2.1 -3.6 2.1 -3.6 0.05 24
DS 2.1 -3.6 2.1 3.6 0.05 24
DS 2.1 3.6 -2.1 3.6 0.05 24
DS -2.1 3.6 -2.1 -3.6 0.05 24
DS -1.5 -3 1.5 -3 0.1 24
DS 1.5 -3 1.5 3 0.1 24
DS 1.5 3 -1.5 3 0.1 24
DS -1.5 3 -1.5 -3 0.1 24
DS -1.5 -2.6 -1.1 -3 0.1 24
DC -1.8 -3.2 -1.7 -3.2 0.254 21
$PAD
Po -1.55 -2.6
Sh "1" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 -2.2
Sh "2" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 -1.8
Sh "3" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 -1.4
Sh "4" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 -1
Sh "5" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 -0.6
Sh "6" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 -0.2
Sh "7" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 0.2
Sh "8" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 0.6
Sh "9" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 1
Sh "10" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 1.4
Sh "11" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 1.8
Sh "12" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 2.2
Sh "13" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1.55 2.6
Sh "14" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1 3
Sh "15" R 0.2 0.5 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.6 3
Sh "16" R 0.2 0.5 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.2 3
Sh "17" R 0.2 0.5 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.2 3
Sh "18" R 0.2 0.5 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.6 3
Sh "19" R 0.2 0.5 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1 3
Sh "20" R 0.2 0.5 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 2.6
Sh "21" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 2.2
Sh "22" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 1.8
Sh "23" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 1.4
Sh "24" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 1
Sh "25" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 0.6
Sh "26" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 0.2
Sh "27" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 -0.2
Sh "28" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 -0.6
Sh "29" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 -1
Sh "30" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 -1.4
Sh "31" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 -1.8
Sh "32" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 -2.2
Sh "33" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1.55 -2.6
Sh "34" R 0.2 0.5 0 0 900
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 1 -3
Sh "35" R 0.2 0.5 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.6 -3
Sh "36" R 0.2 0.5 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0.2 -3
Sh "37" R 0.2 0.5 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.2 -3
Sh "38" R 0.2 0.5 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -0.6 -3
Sh "39" R 0.2 0.5 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po -1 -3
Sh "40" R 0.2 0.5 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$PAD
Po 0 0
Sh "41" R 1.8 4.6 0 0 0
At SMD N 00888000
Ne 0 ""
$EndPAD
$EndMODULE QFN40P300X600X80-41N
$EndLIBRARY
